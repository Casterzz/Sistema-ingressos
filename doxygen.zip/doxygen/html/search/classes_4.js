var searchData=
[
  ['faixaetaria',['FaixaEtaria',['../class_faixa_etaria.html',1,'']]]
];

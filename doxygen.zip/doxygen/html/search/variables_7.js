var searchData=
[
  ['sala',['sala',['../struct_estrutura___apresentacao.html#a7dc48aa1aad8c4d28e3ce4589ea8ee5a',1,'Estrutura_Apresentacao']]],
  ['senha',['senha',['../struct_estrutura___usuario.html#a0d50a45ebf89b39256a217ac20549b0e',1,'Estrutura_Usuario']]]
];

var searchData=
[
  ['estado',['estado',['../struct_estrutura___evento.html#a629aa725afa469036e4504f37f2694b8',1,'Estrutura_Evento']]]
];

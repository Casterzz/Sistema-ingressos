#ifndef CONTROLADORAS_H
#define CONTROLADORAS_H

#include "interfaces.h"
#include "dominios.h"
#include <QApplication>
#include <string>

#include <stdexcept>

using namespace std;

class CntrGeral : public QObject{

    Q_OBJECT

  private:
    IAAutenticacao *cntrIAAutenticacao;
    IAUsuario *cntrIAUsuario;
    IAEventos *cntrIAEventos;
    CPF cpf;
    bool logado = false;

  public:
    void setCntrIAAutenticacao(IAAutenticacao *);
    void setCntrIAUsuario(IAUsuario *);
    void setCntrIAEventos(IAEventos *);

  public slots:
    void executarAutGUI();
    void executarUsuGUI();
    void executarEveGUI();
    void executarDeslogarGUI();

  signals:
    void altere_statusGUI(bool);

};

void inline CntrGeral::setCntrIAAutenticacao(IAAutenticacao *cntrIAAutenticacao) {
    this->cntrIAAutenticacao = cntrIAAutenticacao;
}

void inline CntrGeral::setCntrIAEventos(IAEventos *cntrIAEventos) {
    this->cntrIAEventos = cntrIAEventos;
}

void inline CntrGeral::setCntrIAUsuario(IAUsuario *cntrIAUsuario) {
    this->cntrIAUsuario = cntrIAUsuario;
}

void inline CntrGeral::executarAutGUI() {
    logado = cntrIAAutenticacao->executar_autenticacao(cpf);
    if (logado) {
        cpf = cntrIAAutenticacao->fornecer_cpf();
    }
    emit altere_statusGUI(logado);
}

void inline CntrGeral::executarUsuGUI() {
    if (logado) {
        this->logado = cntrIAUsuario->executar_autenticado(this->cpf);
    } else {
        cntrIAUsuario->executar_novo();
    }
}

void inline CntrGeral::executarEveGUI() {
    cntrIAEventos->executar(this->cpf, logado);
}

void inline CntrGeral::executarDeslogarGUI() {
    logado = false;
}

class CntrIAAutenticacao : public QObject, public IAAutenticacao{

    Q_OBJECT

  private:
    ISAutenticacao *cntrISAutenticacao;
    bool logado = false;
    string cpf;
    string senha;

  public:
    void setCntrISAutenticacao(ISAutenticacao *);
    bool executar_autenticacao(CPF&) throw(runtime_error);
    CPF fornecer_cpf() throw(runtime_error);

  public slots:
    void logarGUI(QString, QString);

  signals:
    void notifique_situacao(int);
};

void inline CntrIAAutenticacao::setCntrISAutenticacao(ISAutenticacao *cntrISAutenticacao) {
    this->cntrISAutenticacao = cntrISAutenticacao;
}

class CntrIAUsuario : public QObject, public IAUsuario{

    Q_OBJECT

  private:
    ISUsuario *cntrISUsuario;
    CPF cpf;
    bool logado = false;

  public:
    void setCntrISUsuario(ISUsuario *);
    bool executar_autenticado(CPF) throw(runtime_error);
    void executar_novo() throw(runtime_error);

  public slots:
    void executarCadastrarGUI(EstruturaUsuario, EstruturaCartaoCredito);
    void executarExcluirUsuarioGUI();
    void excluirUsuarioGUI();
    void executarDadosContaGUI();
    void executarMinhasComprasGUI();
    void executarMeusEventosGUI();
    void processarMeusEventosGUI(int, int);
    void processarCompradoresGUI(int, int, CodigoApresentacao);

    void alterarCPFGUI(string);
    void alterarSenhaGUI(string);
    void alterarCartaoGUI(string);
    void alterarCartaoCodigoGUI(string);
    void alterarCartaoDataGUI(string);

    void alterarNomeEventoGUI(string, string);
    void alterarClasseEventoGUI(string, string);
    void alterarFaixaEventoGUI(string, string);
    void alterarCidadeEventoGUI(string, string);
    void alterarEstadoEventoGUI(string, string);
    void alterarDataApresentacaoGUI(string, string);
    void alterarHorarioApresentacaoGUI(string, string);
    void alterarPrecoApresentacaoGUI(string, string);
    void alterarSalaApresentacaoGUI(string, string);

    void excluirApresentacaoGUI(string);
    void addEventoGUI(EstruturaEvento);
    void addApresentacaoGUI(EstruturaApresentacao);

  signals:
    void notifique_situacao(int);
    void inicia_exclusao_conta(string, string);
    void mostre_dados_conta(EstruturaUsuario, EstruturaCartaoCredito);
    void inicia_mostrar_ingressos(list<Ingresso>, list<Apresentacao>, list<Evento>);
    void inicia_mostrar_meus_eventos(list<Evento>);
    void inicia_vendas_efetuadas(string, list<Apresentacao>);
    void inicia_editar_evento(EstruturaEvento, list<Apresentacao>);
    void status_exclusao_evento(bool);
    void inicia_mostrar_compradores(list<CPF>, CodigoApresentacao);
};

void inline CntrIAUsuario::setCntrISUsuario(ISUsuario *cntrISUsuario) {
    this->cntrISUsuario = cntrISUsuario;
}


class CntrIAEventos : public QObject, public IAEventos{

    Q_OBJECT

  private:
    ISEventos *cntrISEventos;
    IAVendas *cntrIAVendas;
    string cpf;
    bool logado = false;

  public:
    void executarMostrarEventosGUI();
    void setCntrISEventos(ISEventos *);
    void setCntrIAVendas(IAVendas *);
    void executar(CPF, bool) throw(runtime_error);

  public slots:
    void executarMostrarEventosEspGUI(string);
    void processarApresentacoesGUI(CodigoEvento);
    void pre_compra(CodigoEvento, CodigoApresentacao);

  signals:
    void mostre_todos_eventos(list<Evento>);
    void mostre_eventos(list<Evento>);
    void notifique_situacao(int);
    void inicia_apresentacoes_disponiveis(list<Apresentacao>);
    void encerrarEventos();
};


void inline CntrIAEventos::setCntrISEventos(ISEventos *cntrISEventos) {
    this->cntrISEventos = cntrISEventos;
}

void inline CntrIAEventos::setCntrIAVendas(IAVendas *cntrIAVendas) {
    this->cntrIAVendas = cntrIAVendas;
}

//-----------------------------------------

class CntrIAVendas : public QObject, public IAVendas{

    Q_OBJECT

  private:
    ISVendas *cntrISVendas;
    IAVendas *cntrIAVendas;
  public:
    void executar(CPF, CodigoEvento, CodigoApresentacao) throw(runtime_error);
    void setCntrISVendas(ISVendas *);
    void executarMostrarDadosGUI(CPF, CodigoEvento, CodigoApresentacao);
  public slots:
    void executarCompraGUI(CodigoEvento, CodigoApresentacao);
  signals:
    void atualize_dados(CartaoCredito, Evento, Apresentacao);
    void lista_ingressos_adquiridos(list<Ingresso>);
};

void inline CntrIAVendas::setCntrISVendas(ISVendas *cntrISVendas) {
    this->cntrISVendas = cntrISVendas;
}

#endif // CONTROLADORAS_H
